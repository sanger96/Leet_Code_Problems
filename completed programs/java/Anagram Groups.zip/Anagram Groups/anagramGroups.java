import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/*
 * I tried to write this code in the most legable way possible.
 * To that effect I have made methods for each part of the solution.
 * This also helps in debugging.
 */

public class anagramGroups{
    public static List<List<String>> solve(String[] input){
        List<List<String>> output= new ArrayList<>();
        HashMap<String, HashMap<Character, Integer>> allHashedWords= new HashMap<>();

        //idea: I will Hash each word by its characters and compare the hashMaps.
        //To compare a dynamic number of hashMaps for any number of words I will use a ArrayList of HashMaps
        
        //iterate through all words in input
        for(int word=0; word<input.length;word++){

            //grab word from input
            String wholeWord=input[word];

            //Hash the word
            // HashMap<Character, Integer> hashedWord = hashIt(wholeWord);

            //convert it into char[]
            char[] currentWord = wholeWord.toCharArray();
            //hash the word's letters
            HashMap<Character, Integer> wordHash = new HashMap<Character,Integer>();
            for(int letterIndex=0; letterIndex<currentWord.length; letterIndex++){ 
                //to hash each letter, check if letter is hashed

                //letter defined here for clarity
                char letter = currentWord[letterIndex];

                if(wordHash.get(letter) != null){
                    //if letter is hashed; 
                    //then increment the integer representing how many times that letter is in the word.
                    wordHash.put(letter,(wordHash.get(currentWord[letterIndex])+1));
                }else{
                    //if letter is not hashed;
                    //hash letter and set integer value to 1
                    wordHash.put(letter,1);
                }
            }// end of for loop

            //Add the hashedWord to the proper place in solution
            //This is done by iterating through the solution
            //If this hashedWord.equals(first word in sublist of output) then add to sublist
            //If hashedWord isn't equal to first word in any sublist, then add it to new sublist at end of the output.

            //Note all hashedWords are in hashMap of <wholeWord,hashedWord> to be used when checking output against current word.
            //add to allHashedWords
            allHashedWords.put(wholeWord,wordHash);

            //this boolean will change to true if the word was added to an existing sublist
            boolean addedToOutput = false;

            //iterate through the output
            for(int x=0; x<output.size();x++){
                //Note: I only need to check the hashedWord against the first word in sublist
                // all words in sublist should match, and be anagram for each other.
                HashMap<Character, Integer> wordHashToCompare = allHashedWords.get(output.get(x).get(0));
                if(wordHashToCompare.equals(wordHash) ){
                    //if they are equal add wholeWord, represented by hashedWord, to sublist
                    output.get(x).add(wholeWord);
                    addedToOutput=true;
                }
            }

            //if the word is not added to a sublist, aka not an anagram for another word in the output,
            //then add it to a new sublist in the output
            if(addedToOutput==false){
                //create new ArrayList and only add the current word
                ArrayList<String> temp = new ArrayList<>();
                temp.add(wholeWord);
                output.add(temp);
            }
            

            

        }
        return output;
    }// end of solve

    public static HashMap<Character, Integer> hashIt(String wholeWord){
        //convert it into char[]
        char[] currentWord = wholeWord.toCharArray();
        //hash the word's letters
        HashMap<Character, Integer> wordHash = new HashMap<Character,Integer>();
        for(int letterIndex=0; letterIndex<currentWord.length; letterIndex++){ 
            //to hash each letter, check if letter is hashed

            //letter defined here for clarity
            char letter = currentWord[letterIndex];

            if(wordHash.get(letter) != null){
                //if letter is hashed; 
                //then increment the integer representing how many times that letter is in the word.
                wordHash.put(letter,(wordHash.get(currentWord[letterIndex])+1));
            }else{
                //if letter is not hashed;
                //hash letter and set integer value to 1
                wordHash.put(letter,1);
            }
        }// end of for loop
        return wordHash;
    }

}
