// This program is "Anagram Groups" problem file
// The solution is in a file called solution.

// This file will have the test input and will display the output.

/*
 * Anagram Groups
 * Given an array of strings strs, group all anagrams together into sublists.
 * You may return the output in any order.
 * An anagram is a string that contains the exact same characters as another
 * string,
 * but the order of the characters can be different.
 * 
 Constraints:
1 <= strs.length <= 1000.
0 <= strs[i].length <= 100
strs[i] is made up of lowercase English letters.

 */

// ****************************************************************************
// Three examples;

// Input: strs = ["act","pots","tops","cat","stop","hat"]
// Output: [["hat"],["act", "cat"],["stop", "pots", "tops"]]

// Input: strs = ["x"]
// Output: [["x"]]

// Input: strs = [""]
// Output: [[""]]
// ****************************************************************************

public class Main {
    public static void main(String[] args) {

        // instantiate the solution
        // anagramGroups solution = new anagramGroups();
        

        //Test 1 
        String [] input1 = {"act","pots","tops","cat","stop","hat"};
        String expectedSolution1 ="[[hat],[act, cat],[stop, pots, tops]]";
        // String sol = solution.solve(input);
        System.out.println("The solution for test 1 is listed below\n" + anagramGroups.solve(input1) + "\n");
        //System.out.println("The solution for test 1 is listed below\n" + anagramGroupsOnlineSolution.solve(input1) + "\n");
        System.out.println("The solution for test 1 is listed below\n" + expectedSolution1 + "\n\n");

        //Seperator of tests
        System.out.println("*****************************************************************************");

        //Test 2
        String [] input2 = {"x"};
        String expectedSolution2 ="[[x]]";
        // String sol = solution.solve(input);
        System.out.println("The solution for test 1 is listed below\n" + anagramGroups.solve(input2) + "\n");
        //System.out.println("The solution for test 1 is listed below\n" + anagramGroupsOnlineSolution.solve(input2) + "\n");
        System.out.println("The solution for test 1 is listed below\n" + expectedSolution2 + "\n\n");

        //Seperator of tests
        System.out.println("*****************************************************************************");

        //Test 3
        String [] input3 = {""};
        String expectedSolution3 ="[[]]";
        // String sol = solution.solve(input);
        System.out.println("The solution for test 1 is listed below\n" + anagramGroups.solve(input3) + "\n");
        //System.out.println("The solution for test 1 is listed below\n" + anagramGroupsOnlineSolution.solve(input3) + "\n");
        System.out.println("The solution for test 1 is listed below\n" + expectedSolution3 + "\n\n");
    }
}
