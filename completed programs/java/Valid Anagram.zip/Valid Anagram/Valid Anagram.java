class Solution {
    public boolean isAnagram(String s, String t) {
       //idea: any anagram of two string will contain the same letters in both words, and the same number of occurences of those letters
        // add each letter of s and t to hashMaps
        // key= letter, value= occurences of letter
        // compare two hashmaps 
        // equal -> return true
        // not equal -> return false

        //quick fail check
        if(s.length() != t.length()){
            return false;
        }

        //two hashmaps
        HashMap<Character, Integer> hashS = new HashMap<Character, Integer>();
        HashMap<Character, Integer> hashT = new HashMap<Character, Integer>();

        char[] charS = s.toCharArray();
        char[] charT = t.toCharArray();

        for (char c: charS){ //assume s and t are same length
            //handles hashing s
            if(hashS.containsKey(c)){
                hashS.put(c, hashS.get(c)+1);
            }
            else{
                hashS.put(c,1);
            }
        }
        for (char c: charT){ //assume s and t are same length
            //handles hashing s
            if(hashT.containsKey(c)){
                hashT.put(c, hashT.get(c)+1);
            }
            else{
                hashT.put(c,1);
            }
        }
        if(hashS.equals(hashT)){return true;}else{return false;} 
    }
}
