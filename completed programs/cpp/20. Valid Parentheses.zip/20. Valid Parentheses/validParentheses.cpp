#include <string>
#include <iostream>
#include <stack>
#include <algorithm>

using namespace std;

/*
Done: user must enter a given string to be checked. 
See "problem description.txt" for problem details
Approach:
There are stacks for each (), [], {}
When a parentheses is read in and put in the correct stack, (1) the index of the character will be stored.
If the next char is a closing bracket then (2) check to see if the top() of that char's stack is the highest index amoung the stacks,
(3) if it is then pop that char's stack
(4) if it isnt then return false, as its trying to close out of order
(5) Lastly if the for loop has ended and all stacks are empty then return true

Note: since only opening parenthesis indexs are stored checking to see the highest value will tell us which one is supposed to be closed next.

*/

bool isValid(string s){

	//make sure minimum length is met.
	if(s.length()<2){
		return false;
	}

	//initialize the stacks LIFO order
	stack<int> curved;
	stack<int> square;
	stack<int> curly;
	// initialize int for lastOpen parentheses
	stack<char> lastOpen;

	for(int c=0; c<s.length(); c++){
		// note: there is no default case, may add one later to deal with some error checking.
		switch(s[c]){
			//(1) push each char's index into the corresponding stack.
			case '(':
				curved.push(c);
				lastOpen.push(s[c]);
				break;
			case '{':
				curly.push(c);
				lastOpen.push(s[c]);
				break;
			case '[':
				square.push(c);
				lastOpen.push(s[c]);
				break;
			//(2) check to see if the top() of that char's stack is the highest index amoung the stacks
			case ')':
			//handles if the there is no open parentheses and its trying to close.
			if(lastOpen.empty()){
				return false;
			}
				//(3) if it is then pop that char's stack
			if(lastOpen.top()=='('){
				curved.pop();
				lastOpen.pop();
			}else{
				//(4) if it isnt then return false
				return false;
			}
				break;
			case '}':
			//handles if the there is no open parentheses and its trying to close.
			if(lastOpen.empty()){
				return false;
			}
				//(3) if it is then pop that char's stack
			if(lastOpen.top()=='{'){
				curly.pop();
				lastOpen.pop();
			}else{
				//(4) if it isnt then return false
				return false;
			}
				break;
			case ']':
			//handles if the there is no open parentheses and its trying to close.
			if(lastOpen.empty()){
				return false;
			}
			//(3) if it is then pop that char's stack
			if(lastOpen.top()=='['){
				square.pop();
				lastOpen.pop();
			}else{
				//(4) if it isnt then return false
				return false;
			}
			break;
		}// end of outer switch statement

	}// end of for loop

	//test print
	// while(!curved.empty()){
	// 	cout<< curved.top()<<" ";
	// 	curved.pop();
	// }

	//(5) Lastly if the for loop has ended and all stacks are empty then return true
	if(curved.empty() && square.empty() && curly.empty()){
		return true;
	}
	
	return false;

}// end of isValid

int main(){
	string s;
	cout << "Please input a test string: ";
	cin >> s;
	//Test output of the string.
	//cout << "The test string you entered was: " << s << endl;
	bool result = isValid(s);
	cout<< "0 = false, 1 = true\n\n";
	cout << "The result was: "<< result << endl << endl;
}