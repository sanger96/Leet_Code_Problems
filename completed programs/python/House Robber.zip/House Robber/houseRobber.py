#You are a professional robber planning to rob houses along a stree.
#Each house has a certain amount of money stashed, the only constraint
#stopping you from robbing each of them is that adjacent houses have
#security systems conneted and it WILL AUTOMATICALLY CONTACT THE POLICE
#IF TWO ADJACENT HOUSES WERE BROKEN INTO ON THE SAME NIGHT.

#Give an integer array "nums" representing the amount of money of each
#house, return the maximum amount of money you can rob tonight WITHOUT
#ALERTING THE POLICE

#You only need to output the total amount you think can be robbed

#this is just to have a space after the debugging info
print()

#testing the list below
nums = [2,7,9,3,1]

#attempt 2
tmp1,tmp2=0,0

#traverse nums
for nextHouse in nums:
    #note: tmp1 is 2nd house down, and tmp2 is 3rd house down
    #rob next house and 3rd house down OR rob 2nd house down 
    robbed = max(nextHouse+tmp2, tmp1) 
    tmp2=tmp1
    tmp1=robbed

#return tmp1
print (tmp1)