def threeIntSum(nums) -> list[int]: 
    # idea 3 nested for loops
    # run outer loop nd i <= len(nums)-2
    # run middle loop if  i < j and j <= len(nums)-1
    # run inner most loop if j < k
    # in inner most loop add i + j + k to see if it equals 0
    # True: add i,j,k to list of indicies to output
    # False: do nothing
    # at end of loops return output list

    # list to return
    output = []

    for i in range(len(nums)) :
        if i <= len(nums) - 2 :

            for j in range(len(nums)):
                if j <= len(nums)-1 and i != j and j > i:
                    
                    for k in range(len(nums)):
                        if j != k and i != k and k > j:
                            # check if sum is 0
                            if (nums[i]+nums[j]+nums[k]) == 0:
                                # add to list of outputs if not already in it
                                if [nums[i],nums[j],nums[k]] not in output and [nums[i],nums[k],nums[j]] not in output and [nums[j],nums[i],nums[k]] not in output and [nums[j],nums[k],nums[i]] not in output and [nums[k],nums[i],nums[j]] not in output and [nums[k],nums[j],nums[i]] not in output:
                                    output.append([nums[i],nums[j],nums[k]])
    
    return output