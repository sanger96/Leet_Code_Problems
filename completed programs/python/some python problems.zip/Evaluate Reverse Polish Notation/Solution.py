def evalRPN(tokens: list[str]) -> int:
    # idea:
    # 1. if tokens is only one element then thats the answer
    # 2. traverse tokens until a operand is reached
    # 3. apply operand with (index-2) operand (index-1) => result
    # 4. remove index, index -1 and replace index-2 with result  
    # 5. go back to begining of tokens and start at step 1

    # 1. if tokens is only one element then thats the answer
    while len(tokens) != 1 :

        # 2. traverse tokens until a operand is reached
        i = 0
        while tokens[i] != '*' and tokens[i] != '-' and tokens[i] != '+' and tokens[i] != '/':
            i=i+1 # go to next element in tokens
        # 3. apply operand with (index-2) operand (index-1) => result
        result = eval(str(tokens[i-2])+str(tokens[i])+str(tokens[i-1])) # trying to evaluate the string expression
        # 4. remove index, index -1 and replace index-2 with result 
        del tokens[i]
        del tokens[i-1]
        tokens[i-2] = int(result)

    return (tokens[0])