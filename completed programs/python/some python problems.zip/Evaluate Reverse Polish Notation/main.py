# You are given an array of strings tokens that 
# represents a valid arithmetic expression in 
# Reverse Polish Notation.

# Return the integer that represents the 
# evaluation of the expression.

# The operands may be integers or the results 
# of other operations.
# The operators include '+', '-', '*', and '/'.
# Assume that division between integers always 
# truncates toward zero.


# Example 1:
# Input: tokens = ["1","2","+","3","*","4","-"]
# Output: 5
# Explanation: ((1 + 2) * 3) - 4 = 5

import Solution
output = 5
tokens = [["1","2","+","3","*","4","-"], ["4","13","5","/","+"], ["10","6","9","3","+","-11","*","/","*","17","+","5","+"]]

for x in tokens: 
    print(Solution.evalRPN(x))

#**********************************************
#NOTE: The solution only works on neet code if you type cast to round, if you actually round down like the problem asks , using math.floor, or round normally, using round(number.decimal), then the answer will not match what they have.

