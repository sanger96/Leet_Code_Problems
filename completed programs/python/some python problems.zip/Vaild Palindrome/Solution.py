def isPalindrome(s: str) -> bool :
    # idea 
    # 1. convert string into list
    # 2. copy into second list and reverse sort it
    # 3. compare two version of the list
    
    # 1. convert string into list
    # note: not case sensitive && ignore non-alphanumeric characters

    # to hold original list for comparison
    originalList = []

    # ignore case sensitivity
    s=s.lower()

    #ignore non-alphanumeric characters
    for char in s:
        # if char.isalnum : # didnt work as char.isalnum accepted "?"

        # using ASCII values to check if its lettter or number
        # 48 to 57 are numbers 0-9
        # 65 to 90 are A-Z
        # 97 to 122 are a-z
        if (ord(char) >= 48 and ord(char) <= 57) or (ord(char) >= 65 and ord(char) <= 90) or (ord(char) >= 97 and ord(char) <=122) :
            originalList.append(char)


    # 2. copy into second list and reverse sort it
    reverseList=list(reversed(originalList))

    # 3. compare two version of the list
    if reverseList == originalList :
        return True
    else: 
        return False
