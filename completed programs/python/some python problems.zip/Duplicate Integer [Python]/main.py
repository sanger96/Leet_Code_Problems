# This file is to pass a List to the solution.
# This is where the list to be checked will be intantiated.


# The line below imports the solution
import Solution

# lists of nums to test
nums = [[1,2,3,3],[1,2,3,4]]

for tmpList in nums:

    # seperator for easier reading in terminal
    print("***********************************")

    # note that str(non-string) will convert it to a string for print
    print("Commencing check for duplicate integer in following list:\n"+ str(tmpList) + "\n")

    if(Solution.hasDuplicate(tmpList) == True) :
        print("Yes there is a duplicate integer.")
    else:
        print("No there is not a duplicate integer.")

    # seperator for easier reading in terminal
    print("***********************************")

