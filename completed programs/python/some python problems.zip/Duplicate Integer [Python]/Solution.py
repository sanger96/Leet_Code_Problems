# Given an integer array nums, return true if any value appears  more than once in the array, otherwise return false.

def hasDuplicate(nums: list[int])-> bool:
    
    # contains all integers
    hashset = set()
    
    # iterate through the list of integers in nums
    for n in nums:
        # check if integer is already in hashset
        if n in hashset:
            return True
        hashset.add(n)
    return False
    