def twoSum(nums: list[int], target: int ) -> list[int]:

    # idea 
    # 1. iterate through nums and add to each element, other than current, and see if it matches target
    # 2. check for match
    # 2.a if match then output current index and the index being added
    # 2.b if not match move on to next index

    # note: do not need to check nums[0] + nums [1] and nums[1] + nums[0]

    # 1. iterate through nums and add to each element, other than current, and see if it matches target
    for i in range(len(nums)):
        # iterate through elements after i
        restOfNums = nums[i+1:len(nums)]
        for j in range(len(restOfNums)):
            # 2. check for match
            if (nums[i] + restOfNums[j]) == target :
                return [i,i+1+j] # note that i+1+j is restOfNums[j] position in nums