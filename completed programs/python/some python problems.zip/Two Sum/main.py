import Solution

# Given an array of integers nums and an integer target, return the indices i and j such that nums[i] + nums[j] == target and i != j.
# You may assume that every input has exactly one pair of indices i and j that satisfy the condition.
# Return the answer with the smaller index first.

# Example 1
# input: nums = [3,4,5,6], target = 7
# Output: [0,1]
# nums[0]+ nums[1]=7

# Example 2
# Input: nums = [4,5,6], target = 10
# Output: [0,2]
# nums[0]+ nums[2]=10

# Example 3
# Input: nums = [5,5], target = 10
# Output: [0,1]
# nums[0]+ nums[1]=10

numsList = [[3,4,5,6],[4,5,6],[5,5]]
outputs = [[0,1],[0,2],[0,1]]
targets = [7,10,10]

# test the inputs against expected outputs and target numbers, note indicies correspond accross nums outputs and targets

# test all examples
for nums in range(len(numsList)) :
    output =  Solution.twoSum(numsList[nums], targets[nums])
    if output == outputs[nums]:
        
        print("success")
    else: 
        print(output)
        print("Failure\n")