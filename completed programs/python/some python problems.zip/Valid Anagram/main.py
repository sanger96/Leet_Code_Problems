# The line below imports the solution
import Solution

# create and send strings
# each index of s is checked against same index number in t

s = ["racecar","jar"]
t = ["carrace","jam"]

for x in range(len(s)):
    print("Checking if "+ s[x]+ " is an anagram of "+t[x]+"\n"+str(Solution.isAnagram(s[x],t[x])))
    print("-----------------------------------------") # to separate multiple runs of program
