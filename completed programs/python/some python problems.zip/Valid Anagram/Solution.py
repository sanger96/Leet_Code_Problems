# the "-> bool" makes this have a return type of bool
def isAnagram(s:str, t:str) -> bool:
    
    list1= []
    list2= []

    # quick fail check
    # if the two strings are not the same size then fail
    if len(s) != len(t):
        return False
    
    # iterate length of the strings and insert into hash sets
    for c in range(len(s)):
        list1.append(s[c])
        list2.append(t[c])
    
    # sort the lists
    list1.sort()
    list2.sort()
    
    if list1 == list2 :
        return True
    else:
        return False
