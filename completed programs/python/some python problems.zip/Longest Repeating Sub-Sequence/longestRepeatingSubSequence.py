string=['d','v','d','f']
#this is the first index of the maximum sub string
firstIndex = 0

#this will contain all the indecies of the chars in the string
indexOfChars = {} 

#this will be the running total for the maximum length substring
maxSubString = 0

for i in range(len(string)): 

    #is the current char already in the indexOfChars
    if string[i] in indexOfChars: 
        firstIndex = max(firstIndex, indexOfChars[string[i]] + 1) 

    #set new max
    maxSubString = max(maxSubString, i-firstIndex + 1) 

    #add current char to indexOfChars
    indexOfChars[string[i]] = i 
  
answer= maxSubString


print("***Answer is below***")
print(answer)