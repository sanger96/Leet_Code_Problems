class MinStack:

    def __init__(self):
        self.stack = []
        return None

    def push(self, val: int) -> None:
        # add int to stack
        self.stack.append(val)
        return None

    def pop(self) -> None:
        # access last elment in stack
        out = self.stack.pop(len(self.stack)-1)
        return None
        #return out

    def top(self) -> int:
        # return top of stack aka end of list
        return self.stack[len(self.stack)-1]
        

    def getMin(self) -> int:
        tmp = self.stack.copy()
        tmp.sort()
        return tmp[0]