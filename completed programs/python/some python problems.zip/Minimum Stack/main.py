import Solution

minStack = Solution.MinStack()

print(minStack.push(-1))
print(minStack.push(1))
print(minStack.push(-1))
print(minStack.pop()) # pops -1
print(minStack.top())  # return 1
print(minStack.getMin() )# return -1