def isValid(s: str) -> bool: 
    # idea 
    # 1. traverse characters in string s 
    # 2. push each type open bracket onto stack 
    # 3. on close bracket;
    # 3.a if same type as previous open bracket pop open bracket
    # 3.b if not same type as previous open bracket return False
    # 4. If string is completely traversed and stack empty return True

    stack = []

    # 1. traverse characters in string s 
    for bracket in s :
        # 2. push each type open bracket onto stack 
        if bracket == "(" or bracket == "{" or bracket == "[" :
            stack.append(bracket)
        # 3. on close bracket;
        elif bracket == ")" or bracket == "}" or bracket == "]" :
            # simple fix for fringe case of "]"
            if(len(stack)==0):
                return False
            # 3.a if same type as previous open bracket pop open bracket
            perviousBracket = stack[(len(stack)-1)]
            if perviousBracket == "(" and bracket == ")":
                stack.pop()
            elif perviousBracket == "[" and bracket == "]":
                stack.pop()
            elif perviousBracket == "{" and bracket == "}":
                stack.pop()
            # 3.b if not same type as previous open bracket return False
            else :
                return False        
    
    # 4. If string is completely traversed and stack empty return True
    if len(stack) == 0 :
        return True
    else:
        return False




