def twoSum(nums: list[int], target: int) -> list[int]:
    for i in range(len(nums)):
                # iterate through elements after i
                restOfNums = nums[i+1:len(nums)]
                for j in range(len(restOfNums)):
                    # 2. check for match
                    if (nums[i] + restOfNums[j]) == target :
                        return [i+1,i+2+j] # note that i+1+j is restOfNums[j] position in nums