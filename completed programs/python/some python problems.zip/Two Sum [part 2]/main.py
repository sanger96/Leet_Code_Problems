# Given an array of integers numbers that is sorted in non-decreasing order.

# Return the indices (1-indexed) of two numbers, [index1, index2], 
# such that they add up to a given target number target and index1 < index2. 
# Note that index1 and index2 cannot be equal, therefore you may not use the same element twice.

# There will always be exactly one valid solution.

# Your solution must use 
# O(1) additional space.

# Example 1:
# Input: numbers = [1,2,3,4], target = 3

# Output: [1,2]

# used same code as first version, it was already efficient enough

import Solution

numsList = [[3,4,5,6],[4,5,6],[5,5]]
outputs = [[1,2],[1,3],[1,2]]
targets = [7,10,10]

# test the inputs against expected outputs and target numbers, note indicies correspond accross nums outputs and targets

# test all examples
for nums in range(len(numsList)) :
    output =  Solution.twoSum(numsList[nums], targets[nums])
    if output == outputs[nums]:
        
        print("success")
    else: 
        print(output)
        print("Failure\n")