class Solution:
    def isPalindrome(self, x: int) -> bool:
        dig=[]
        dig2=[]
        for digit in str(x):
            # takes care of negative numbers
            if(digit == "-"):
                return False
            dig.append(int(digit))
            dig2.append(int(digit))
        #reverse first dig aka original input
        dig.reverse()

        #compare and return result
        if(dig == dig2):
            #print(True)
            return True
        else:
            #print(False)
            return False
