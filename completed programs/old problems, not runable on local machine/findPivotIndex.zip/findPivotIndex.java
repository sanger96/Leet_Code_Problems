class Solution {
    public int pivotIndex(int[] nums) {
        int leftSum =0, rightSum =0;
        for (int pivotIndex = 0; pivotIndex<nums.length; pivotIndex++){
            for(int j=0; j<pivotIndex; j ++){
                leftSum+= nums[j];
            }
            for(int j=nums.length -1 ; j>pivotIndex; j--){
                rightSum += nums[j];
            }
            if(leftSum==rightSum){
                return pivotIndex;
            }else{
                leftSum=0;
                rightSum=0;
            }
        }
    return -1;
    }
}
