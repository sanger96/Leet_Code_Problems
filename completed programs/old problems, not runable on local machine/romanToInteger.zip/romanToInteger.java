class Solution {
    public int romanToInt(String s) {
        int sum=0;
        String split[] = s.split("",s.length());
        for(int x=0; x<split.length; x++){
            //checks for subtraction cases suing current and next char
            //skips switch case b/c subtraction has happend
            int sub=0;
            //prevents array out of bounds
            if(x+1>=0 && x+1 < split.length){
            //I followed by V or X
            if(split[x].equals("I")){
                if(split[x+1].equals("V")){
                    sum+=4;
                    // x++ will skip the following char if used in this section, also the break will skip the next char in the case it is the last one in the string.
                    if(x+2 < split.length){x++;}
                    else{break;}
                    sub=1;
                }
                if(split[x+1].equals("X")){
                    sum+=9;
                    if(x+2 < split.length){x++;}
                    else{break;}
                    sub=1;
                }
            }
            //X followed by L or C
            if(split[x].equals("X")){
                if(split[x+1].equals("L")){
                    sum+=40;
                    if(x+2 < split.length){x++;}
                    else{break;}
                    sub=1;
                }
                if(split[x+1].equals("C")){
                    sum+=90;
                    if(x+2 < split.length){x++;}
                    else{break;}
                    sub=1;
                }
            }
            //C followed by D or M
            if(split[x].equals("C")){
                if(split[x+1].equals("D")){
                    sum+=400;
                    if(x+2 < split.length){x++;}
                    else{break;}
                    sub=1;
                }
                if(split[x+1].equals("M")){
                    sum+=900;
                    if(x+2 < split.length){x++;}
                    else{break;}
                    sub=1;
                }
            }
            }

            if(sub == 0){
            //add single char roman numeral
            switch(split[x]){
                case "I":
                    sum+=1;
                    break;
                case "V":
                    sum+=5;
                    break;
                case "X":
                    sum+=10;
                    break;
                case "L":
                    sum+=50;
                    break;
                case "C":
                    sum+=100;
                    break;
                case "D":
                    sum+=500;
                    break;
                case "M":
                    sum+=1000;
                    break;
            }
        }
        }
        
        return sum;
    }
}
