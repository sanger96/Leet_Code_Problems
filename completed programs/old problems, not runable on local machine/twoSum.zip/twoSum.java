class Solution {
    public int[] twoSum(int[] nums, int target) {
        int[] indicies= new int[2];
        for(int j=0; j < nums.length; j++){
            for(int k=0 ; k <nums.length; k++  ){
                if(target == (nums[j] + nums[k]) && j !=k){
                    indicies[0] = j;
                    indicies[1] = k;

                }
            }
        }
    return indicies;}
}
