class Solution {
    public int[] runningSum(int[] nums) {
        int [] runSum= new int[nums.length];
        for(int j=0; j<nums.length; j++){
            for(int k=0; k<j+1; k++){
                runSum[j] += nums[k];
            }
        }
    return runSum;}
}
