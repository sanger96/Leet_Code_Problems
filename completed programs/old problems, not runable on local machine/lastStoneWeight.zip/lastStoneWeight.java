class Solution {
    public int lastStoneWeight(int[] stones) {
        ArrayList<Integer> s = new ArrayList<Integer>();
        for(int x=0; x<stones.length;x++){
            s.add(stones[x]);
        }

        while(s.size()>1){
            Collections.sort(s);
            Collections.reverse(s);
            if(s.get(0)==s.get(1)){
                s.remove(0);
                s.remove(0);
            }else{
                s.add(s.get(0)-s.get(1));
                s.remove(0);
                s.remove(0);
            }
        }
        if(s.size()==0){
            return 0;
        }
        return s.get(0);
    }
}
